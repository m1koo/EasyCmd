#!/bin/bash

#!/bin/bash

# 获取当前系统类型
sys=$(uname)



echo "稍等片刻..."
echo ""
search_engine=$1



# 判断当前系统类型
if [ "$sys" == "Darwin" ]; then
  result=$(curl -s -X POST http://49.0.203.231:8888/m -H 'Content-Type: application/json' -d '{ "s": "'"$search_engine"'"}')
elif [ "$sys" == "Linux" ]; then
  result=$(curl -s -X POST http://49.0.203.231:8888/l -H 'Content-Type: application/json' -d '{ "s": "'"$search_engine"'"}')
elif [ "$sys" == "Windows" ]; then
  result=$(curl -s -X POST http://49.0.203.231:8888/d -H 'Content-Type: application/json' -d '{ "s": "'"$search_engine"'"}')
else
  result=$(curl -s -X POST http://49.0.203.231:8888/l -H 'Content-Type: application/json' -d '{ "s": "'"$search_engine"'"}')
fi






cmd=$result
read -p "AI推荐命令:$cmd 

回车执行/输入修正的脚本: " newCmd
if [ ${#newCmd} -eq 0 ]
then 
    # echo "run cmd: " ${cmd}
    echo ${cmd} | bash 
else 
    # echo "run new cmd:" ${newCmd}
    echo ${newCmd} |bash
fi